-- NFL Reseeding Support Migration
-- Run this in Supabase SQL Editor

-- 1. Add reseeding flag to events
ALTER TABLE events ADD COLUMN IF NOT EXISTS uses_reseeding BOOLEAN DEFAULT FALSE;

-- 2. Create advancement_picks table for reseeding events
CREATE TABLE IF NOT EXISTS advancement_picks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pool_entry_id UUID NOT NULL REFERENCES pool_entries(id) ON DELETE CASCADE,
  team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  round_id UUID NOT NULL REFERENCES rounds(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(pool_entry_id, team_id, round_id)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_advancement_picks_entry ON advancement_picks(pool_entry_id);
CREATE INDEX IF NOT EXISTS idx_advancement_picks_team ON advancement_picks(team_id);
CREATE INDEX IF NOT EXISTS idx_advancement_picks_round ON advancement_picks(round_id);

-- 3. Add conference to teams (for NFL AFC/NFC separation)
ALTER TABLE teams ADD COLUMN IF NOT EXISTS conference TEXT;

-- 4. Add has_bye flag to teams (for #1 seeds that skip Wild Card)
ALTER TABLE teams ADD COLUMN IF NOT EXISTS has_bye BOOLEAN DEFAULT FALSE;

-- 5. Track team elimination (derived from matchup results, but useful for queries)
-- This is optional - we can derive from matchups, but this makes queries easier
CREATE TABLE IF NOT EXISTS team_eliminations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  team_id UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  eliminated_in_round_id UUID REFERENCES rounds(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(event_id, team_id)
);

CREATE INDEX IF NOT EXISTS idx_team_eliminations_event ON team_eliminations(event_id);

-- 6. Row Level Security for advancement_picks
ALTER TABLE advancement_picks ENABLE ROW LEVEL SECURITY;

-- Allow anyone to read advancement picks
CREATE POLICY "Anyone can read advancement picks" ON advancement_picks
  FOR SELECT USING (true);

-- Allow anyone to insert advancement picks (we validate in app)
CREATE POLICY "Anyone can insert advancement picks" ON advancement_picks
  FOR INSERT WITH CHECK (true);

-- Allow users to update their own picks (before lock)
CREATE POLICY "Anyone can update advancement picks" ON advancement_picks
  FOR UPDATE USING (true);

-- Allow deletion
CREATE POLICY "Anyone can delete advancement picks" ON advancement_picks
  FOR DELETE USING (true);

-- 7. RLS for team_eliminations (admin only write, anyone read)
ALTER TABLE team_eliminations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read team eliminations" ON team_eliminations
  FOR SELECT USING (true);

-- Note: Insert/Update/Delete should use service role key (admin)

-- 8. Function to calculate advancement standings
CREATE OR REPLACE FUNCTION calculate_advancement_standings(p_pool_id UUID)
RETURNS TABLE (
  rank BIGINT,
  entry_id UUID,
  entry_name TEXT,
  email TEXT,
  total_points INTEGER,
  correct_picks INTEGER,
  total_picks INTEGER
) AS $$
BEGIN
  RETURN QUERY
  WITH pool_info AS (
    SELECT p.id, p.event_id
    FROM pools p
    WHERE p.id = p_pool_id
  ),
  round_points AS (
    SELECT r.id as round_id, r.points, r.round_order
    FROM rounds r
    JOIN pool_info pi ON r.event_id = pi.event_id
  ),
  -- Get teams that actually advanced past each round
  actual_advancement AS (
    SELECT DISTINCT
      te.team_id,
      r.id as round_id,
      r.round_order
    FROM team_eliminations te
    JOIN pool_info pi ON te.event_id = pi.event_id
    JOIN rounds r ON r.event_id = pi.event_id
    -- Team advanced past round if they were eliminated in a LATER round or not eliminated
    WHERE te.eliminated_in_round_id IS NULL 
       OR (SELECT round_order FROM rounds WHERE id = te.eliminated_in_round_id) > r.round_order
  ),
  -- Score each pick
  pick_scores AS (
    SELECT
      ap.pool_entry_id,
      ap.team_id,
      ap.round_id,
      rp.points,
      CASE WHEN aa.team_id IS NOT NULL THEN 1 ELSE 0 END as is_correct
    FROM advancement_picks ap
    JOIN pool_entries pe ON ap.pool_entry_id = pe.id
    JOIN pool_info pi ON pe.pool_id = pi.id
    JOIN round_points rp ON ap.round_id = rp.round_id
    LEFT JOIN actual_advancement aa ON ap.team_id = aa.team_id AND ap.round_id = aa.round_id
  ),
  -- Aggregate by entry
  entry_totals AS (
    SELECT
      pe.id as entry_id,
      pe.entry_name,
      pe.email,
      COALESCE(SUM(CASE WHEN ps.is_correct = 1 THEN ps.points ELSE 0 END), 0)::INTEGER as total_points,
      COALESCE(SUM(ps.is_correct), 0)::INTEGER as correct_picks,
      COUNT(ps.pool_entry_id)::INTEGER as total_picks
    FROM pool_entries pe
    LEFT JOIN pick_scores ps ON pe.id = ps.pool_entry_id
    WHERE pe.pool_id = p_pool_id
    GROUP BY pe.id, pe.entry_name, pe.email
  )
  SELECT
    RANK() OVER (ORDER BY et.total_points DESC, et.entry_name ASC)::BIGINT as rank,
    et.entry_id,
    et.entry_name,
    et.email,
    et.total_points,
    et.correct_picks,
    et.total_picks
  FROM entry_totals et
  ORDER BY et.total_points DESC, et.entry_name ASC;
END;
$$ LANGUAGE plpgsql;

-- 9. Verify migration
SELECT 'Migration complete. Tables created:' as status;
SELECT tablename FROM pg_tables WHERE tablename IN ('advancement_picks', 'team_eliminations');
