// Standings Page Integration for NFL Reseeding Events
// Add this to app/pool/[poolId]/standings/page.js

// At the top of the file, update the pool query to include uses_reseeding:
const { data: pool } = await supabase
  .from('pools')
  .select(`
    *, 
    event:events(
      id, name, year, start_time, season_id, event_type, uses_reseeding,
      season:seasons(id, name)
    )
  `)
  .eq('id', poolId)
  .single()

// After the pool query, determine which standings function to use:
const usesReseeding = pool.event?.uses_reseeding === true

// Replace the standings query with:
let standings = []
if (usesReseeding) {
  // Use advancement standings for NFL-style events
  const { data } = await supabase
    .rpc('calculate_advancement_standings', { p_pool_id: poolId })
  standings = data || []
} else {
  // Use standard standings
  const { data } = await supabase
    .rpc('calculate_standings', { p_pool_id: poolId })
  standings = data || []
}

// ============================================
// FULL INTEGRATION EXAMPLE
// ============================================
// Here's what the updated section should look like:

export default async function StandingsPage({ params }) {
  const { poolId } = await params

  const { data: pool } = await supabase
    .from('pools')
    .select(`
      *, 
      event:events(
        id, name, year, start_time, season_id, event_type, uses_reseeding,
        season:seasons(id, name)
      )
    `)
    .eq('id', poolId)
    .single()

  if (!pool) {
    return <div style={{ padding: 24 }}>Pool not found</div>
  }

  const usesReseeding = pool.event?.uses_reseeding === true

  // Get standings using appropriate method
  let standings = []
  if (usesReseeding) {
    const { data } = await supabase
      .rpc('calculate_advancement_standings', { p_pool_id: poolId })
    standings = data || []
  } else {
    const { data } = await supabase
      .rpc('calculate_standings', { p_pool_id: poolId })
    standings = data || []
  }

  const season = pool.event?.season
  const isLocked = new Date(pool.event.start_time) < new Date()

  // ... rest of the component

  // ============================================
  // For "My Picks" in reseeding events:
  // ============================================
  // Instead of showing matchup picks, show advancement picks:

  if (usesReseeding && isLocked) {
    // Get rounds
    const { data: rounds } = await supabase
      .from('rounds')
      .select('id, name, round_order, points')
      .eq('event_id', pool.event.id)
      .order('round_order')

    // Get teams
    const { data: teams } = await supabase
      .from('teams')
      .select('id, name, seed, conference')
      .eq('event_id', pool.event.id)

    // Get eliminations (actual results)
    const { data: eliminations } = await supabase
      .from('team_eliminations')
      .select('team_id, eliminated_in_round_id')
      .eq('event_id', pool.event.id)

    // Get user's picks
    const { data: myEntry } = await supabase
      .from('pool_entries')
      .select('id')
      .eq('pool_id', poolId)
      .eq('email', userEmail) // you'll need to get this from context
      .single()

    if (myEntry) {
      const { data: myPicks } = await supabase
        .from('advancement_picks')
        .select('team_id, round_id')
        .eq('pool_entry_id', myEntry.id)

      // Now you can display:
      // - For each round, which teams user picked to advance
      // - Check against actual eliminations to show correct/incorrect
    }
  }

  // ============================================
  // Disabling Scenario Simulator for reseeding:
  // ============================================
  // The current ScenarioSimulator doesn't support advancement picks.
  // For now, hide it for reseeding events:

  {!usesReseeding && isLocked && undecidedMatchups.length > 0 && (
    <ScenarioSimulator
      standings={standings}
      undecidedMatchups={undecidedMatchups}
      userPicks={userPicks}
      pool={pool}
    />
  )}

  // ============================================
  // Path to Victory for reseeding events:
  // ============================================
  // Different logic needed - for now, hide it:

  {!usesReseeding && (
    <PathToVictory /* ... */ />
  )}
}

// ============================================
// MyPicks Display for NFL Events
// ============================================
// Create a new component or update MyPicksButton to handle advancement picks:

function NFLMyPicks({ entry, rounds, teams, eliminations, picks }) {
  const teamMap = Object.fromEntries(teams.map(t => [t.id, t]))
  const roundMap = Object.fromEntries(rounds.map(r => [r.id, r]))
  const elimMap = Object.fromEntries(eliminations.map(e => [e.team_id, e.eliminated_in_round_id]))

  return (
    <div>
      <h3>Your Picks</h3>
      {rounds.map(round => {
        const roundPicks = picks.filter(p => p.round_id === round.id)
        
        return (
          <div key={round.id} style={{ marginBottom: 16 }}>
            <h4>{round.name} ({round.points} pts)</h4>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {roundPicks.map(pick => {
                const team = teamMap[pick.team_id]
                const elimRoundId = elimMap[pick.team_id]
                const elimRound = elimRoundId ? roundMap[elimRoundId] : null
                
                // Did team advance past this round?
                const teamAdvanced = !elimRoundId || 
                  (elimRound && elimRound.round_order > round.round_order)

                return (
                  <div key={pick.team_id} style={{
                    padding: '8px 12px',
                    background: teamAdvanced ? '#dcfce7' : '#fee2e2',
                    borderRadius: 6,
                    border: `1px solid ${teamAdvanced ? '#16a34a' : '#ef4444'}`
                  }}>
                    #{team?.seed} {team?.name}
                    {teamAdvanced ? ' ✓' : ' ✗'}
                  </div>
                )
              })}
            </div>
          </div>
        )
      })}
    </div>
  )
}
