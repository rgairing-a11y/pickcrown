# NFL Reseeding Implementation

## Overview

This implementation adds support for NFL playoff brackets where:
- Teams are **reseeded** after each round
- Users pick **team advancement** (not specific matchups)
- **Survival Consistency Rule** prevents self-contradictory brackets

## Files Included

```
nfl-reseeding/
├── 001-schema-migration.sql      # Database schema changes
├── 002-sample-nfl-setup.sql      # Sample NFL playoff event
├── AdvancementPickForm.js        # New pick form component
├── pool-page.js                  # Updated pool page
├── nfl-results-page.js           # Admin results entry page
└── README.md                     # This file
```

## Deployment Steps

### Step 1: Run Schema Migration

In Supabase SQL Editor, run `001-schema-migration.sql`

This creates:
- `advancement_picks` table
- `team_eliminations` table
- `uses_reseeding` column on events
- `conference` and `has_bye` columns on teams
- `calculate_advancement_standings` function

### Step 2: Deploy Code Files

```powershell
# 1. Add new component
Copy-Item AdvancementPickForm.js -Destination "components\AdvancementPickForm.js"

# 2. Update pool page  
Copy-Item pool-page.js -Destination "app\pool\[poolId]\page.js"

# 3. Add NFL results admin page
New-Item -ItemType Directory -Force -Path "app\admin\events\[eventId]\nfl-results"
Copy-Item nfl-results-page.js -Destination "app\admin\events\[eventId]\nfl-results\page.js"

# 4. Add eliminations API route
New-Item -ItemType Directory -Force -Path "app\api\events\[eventId]\eliminations"
Copy-Item api-eliminations-route.js -Destination "app\api\events\[eventId]\eliminations\route.js"

# 5. Commit and deploy
git add .
git commit -m "feat: NFL reseeding bracket support"
git push
```

### Step 3: Create NFL Playoff Event

Run `002-sample-nfl-setup.sql` in Supabase, OR create manually:

1. Create event with `uses_reseeding = TRUE`
2. Create rounds: Wild Card, Divisional, Conference Championship, Super Bowl
3. Create teams with `conference` (AFC/NFC) and `has_bye` flag
4. Create Wild Card matchups only (these are fixed)
5. Create pool(s)

## How It Works

### Pick Flow (User)

1. User sees **Wild Card** matchups with real opponents
2. User picks winners (normal bracket style)
3. For **Divisional+**, user sees teams that are "alive" in their bracket
4. User picks N teams to advance (not matchup winners)
5. **Survival Rule**: Can't pick a team you eliminated earlier

### Results Flow (Admin)

1. After each round, admin goes to `/admin/events/[eventId]/nfl-results`
2. Admin marks which teams were **eliminated** in that round
3. System calculates standings based on advancement picks

### Scoring

For each pick:
- User picked team X to advance past Round N
- If team X actually advanced past Round N → award round points
- If team X was eliminated in Round N or earlier → no points

**Max points (7-team format with byes):**
- Wild Card: 3 winners × 2 conf × 3 pts = 18 pts
- Divisional: 2 winners × 2 conf × 5 pts = 20 pts  
- Conference: 1 winner × 2 conf × 8 pts = 16 pts
- Super Bowl: 1 winner × 13 pts = 13 pts
- **Total: 67 pts**

## Key Concepts

### Survival Consistency Rule

> A team may only be selected in Round N if that team is still "alive" in the user's own picks from Round N-1

This is enforced in `AdvancementPickForm.js`:
- `isTeamAlive(teamId, roundOrder)` checks if user picked team to advance from previous round
- Eliminated teams are disabled/unselectable in later rounds
- Unpicking a team cascades removal from all later rounds

### Reseeding Note

The UI does NOT show future matchup pairings because:
- After Wild Card, #1 plays lowest remaining seed
- We can't show "Bills vs ???" because we don't know

Instead, UI shows:
- "Pick 2 teams to advance from AFC"
- Gray out teams you already eliminated

### Data Model

**advancement_picks:**
```
pool_entry_id  →  Who made the pick
team_id        →  Which team
round_id       →  "Advance past this round"
```

**team_eliminations:**
```
event_id               →  Which event
team_id                →  Which team
eliminated_in_round_id →  When they were knocked out (NULL if champion)
```

## Standings Integration

To show standings for NFL reseeding events, use:

```javascript
// Check if reseeding event
if (event.uses_reseeding) {
  const { data } = await supabase.rpc('calculate_advancement_standings', { 
    p_pool_id: poolId 
  })
  // data = [{ rank, entry_id, entry_name, email, total_points, correct_picks, total_picks }]
}
```

## Testing Checklist

- [ ] Schema migration runs without errors
- [ ] Sample NFL event creates correctly
- [ ] Pool page detects `uses_reseeding` and shows AdvancementPickForm
- [ ] Wild Card picks work (normal matchup style)
- [ ] Divisional picks show only teams alive from Wild Card
- [ ] Survival rule enforced (can't pick eliminated team)
- [ ] Super Bowl pick works (single winner from both conferences)
- [ ] Submit saves to `advancement_picks` table
- [ ] Admin results page loads
- [ ] Marking eliminations saves to `team_eliminations`
- [ ] Standings calculate correctly
- [ ] Champion detection works (1 team alive)

## Future Enhancements

1. **My Picks view for advancement** - Show which teams user picked per round
2. **Path to Victory for NFL** - Different logic since no fixed matchups
3. **Auto-lock per round** - Currently all picks lock before Wild Card
4. **Bracket visualization** - Show actual bracket as it forms

## Questions?

This implementation follows the NFL Bracket Master Prompt spec:
- Single lock before Wild Card ✅
- Pick "how far each team advances" ✅
- Survival Consistency Rule ✅
- Honest UI (no fake future matchups) ✅
- No per-round locks ✅
- No conditional picks ✅
