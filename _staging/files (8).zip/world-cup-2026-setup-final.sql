-- ============================================
-- WORLD CUP 2026 - COMPLETE SETUP SCRIPT
-- ============================================
-- Based on December 5, 2025 Draw Results
-- 
-- Run in Supabase SQL Editor
-- Execute each section in order
-- ============================================


-- ============================================
-- PART 1: CREATE EVENT
-- ============================================

INSERT INTO events (id, name, year, event_type, start_time, status)
VALUES (
  gen_random_uuid(),
  'FIFA World Cup 2026',
  2026,
  'hybrid',
  '2026-06-11 15:00:00-04',  -- Mexico vs South Africa opener
  'draft'
)
RETURNING id, name;

-- ⚠️ COPY THE RETURNED ID
-- Find/Replace [EVENT_ID] below with your actual ID


-- ============================================
-- PART 2: CREATE PHASES
-- ============================================

INSERT INTO phases (id, event_id, name, phase_order, lock_time, status) VALUES
(gen_random_uuid(), '[EVENT_ID]', 'Group Stage Picks', 1, '2026-06-11 14:00:00-04', 'draft'),
(gen_random_uuid(), '[EVENT_ID]', 'Knockout Bracket', 2, '2026-06-28 11:00:00-04', 'draft');

-- Verify
SELECT id, name, status FROM phases WHERE event_id = '[EVENT_ID]' ORDER BY phase_order;


-- ============================================
-- PART 3: CREATE ALL 48 TEAMS
-- ============================================
-- 6 teams TBD until March 2026 playoffs

INSERT INTO teams (event_id, name, seed, region) VALUES
-- GROUP A (Mexico's Group)
('[EVENT_ID]', 'Mexico', 1, 'Group A'),
('[EVENT_ID]', 'South Africa', 2, 'Group A'),
('[EVENT_ID]', 'Korea Republic', 3, 'Group A'),
('[EVENT_ID]', 'UEFA Playoff D', 4, 'Group A'),  -- Czechia/Ireland/Denmark/N.Macedonia

-- GROUP B (Canada's Group)  
('[EVENT_ID]', 'Canada', 1, 'Group B'),
('[EVENT_ID]', 'UEFA Playoff A', 2, 'Group B'),  -- Italy/N.Ireland/Wales/Bosnia
('[EVENT_ID]', 'Qatar', 3, 'Group B'),
('[EVENT_ID]', 'Switzerland', 4, 'Group B'),

-- GROUP C
('[EVENT_ID]', 'Brazil', 1, 'Group C'),
('[EVENT_ID]', 'Morocco', 2, 'Group C'),
('[EVENT_ID]', 'Haiti', 3, 'Group C'),
('[EVENT_ID]', 'Scotland', 4, 'Group C'),

-- GROUP D (USA's Group)
('[EVENT_ID]', 'USA', 1, 'Group D'),
('[EVENT_ID]', 'Paraguay', 2, 'Group D'),
('[EVENT_ID]', 'Australia', 3, 'Group D'),
('[EVENT_ID]', 'UEFA Playoff C', 4, 'Group D'),  -- Slovakia/Kosovo/Türkiye/Romania

-- GROUP E
('[EVENT_ID]', 'Germany', 1, 'Group E'),
('[EVENT_ID]', 'Ecuador', 2, 'Group E'),
('[EVENT_ID]', 'Côte d''Ivoire', 3, 'Group E'),
('[EVENT_ID]', 'Curaçao', 4, 'Group E'),

-- GROUP F
('[EVENT_ID]', 'Netherlands', 1, 'Group F'),
('[EVENT_ID]', 'Japan', 2, 'Group F'),
('[EVENT_ID]', 'UEFA Playoff B', 3, 'Group F'),  -- Ukraine/Sweden/Poland/Albania
('[EVENT_ID]', 'Tunisia', 4, 'Group F'),

-- GROUP G
('[EVENT_ID]', 'Belgium', 1, 'Group G'),
('[EVENT_ID]', 'Egypt', 2, 'Group G'),
('[EVENT_ID]', 'Iran', 3, 'Group G'),
('[EVENT_ID]', 'New Zealand', 4, 'Group G'),

-- GROUP H
('[EVENT_ID]', 'Spain', 1, 'Group H'),
('[EVENT_ID]', 'Uruguay', 2, 'Group H'),
('[EVENT_ID]', 'Saudi Arabia', 3, 'Group H'),
('[EVENT_ID]', 'Cape Verde', 4, 'Group H'),

-- GROUP I
('[EVENT_ID]', 'France', 1, 'Group I'),
('[EVENT_ID]', 'Senegal', 2, 'Group I'),
('[EVENT_ID]', 'Intercontinental 2', 3, 'Group I'),  -- Bolivia/Suriname/Iraq
('[EVENT_ID]', 'Norway', 4, 'Group I'),

-- GROUP J
('[EVENT_ID]', 'Argentina', 1, 'Group J'),
('[EVENT_ID]', 'Algeria', 2, 'Group J'),
('[EVENT_ID]', 'Austria', 3, 'Group J'),
('[EVENT_ID]', 'Jordan', 4, 'Group J'),

-- GROUP K
('[EVENT_ID]', 'Portugal', 1, 'Group K'),
('[EVENT_ID]', 'Intercontinental 1', 2, 'Group K'),  -- DR Congo/Jamaica/New Caledonia
('[EVENT_ID]', 'Uzbekistan', 3, 'Group K'),
('[EVENT_ID]', 'Colombia', 4, 'Group K'),

-- GROUP L
('[EVENT_ID]', 'England', 1, 'Group L'),
('[EVENT_ID]', 'Croatia', 2, 'Group L'),
('[EVENT_ID]', 'Ghana', 3, 'Group L'),
('[EVENT_ID]', 'Panama', 4, 'Group L');

-- Verify (should be 48 teams)
SELECT region, name, seed FROM teams WHERE event_id = '[EVENT_ID]' ORDER BY region, seed;


-- ============================================
-- PART 4: CREATE GROUP STAGE CATEGORIES
-- ============================================

-- First get the Phase 1 ID
SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage Picks';
-- Replace [PHASE1_ID] below

INSERT INTO categories (id, event_id, name, order_index, phase_id, points) VALUES
-- Group A
(gen_random_uuid(), '[EVENT_ID]', 'Group A - Winner', 1, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group A - Runner-up', 2, '[PHASE1_ID]', 2),
-- Group B
(gen_random_uuid(), '[EVENT_ID]', 'Group B - Winner', 3, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group B - Runner-up', 4, '[PHASE1_ID]', 2),
-- Group C
(gen_random_uuid(), '[EVENT_ID]', 'Group C - Winner', 5, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group C - Runner-up', 6, '[PHASE1_ID]', 2),
-- Group D
(gen_random_uuid(), '[EVENT_ID]', 'Group D - Winner', 7, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group D - Runner-up', 8, '[PHASE1_ID]', 2),
-- Group E
(gen_random_uuid(), '[EVENT_ID]', 'Group E - Winner', 9, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group E - Runner-up', 10, '[PHASE1_ID]', 2),
-- Group F
(gen_random_uuid(), '[EVENT_ID]', 'Group F - Winner', 11, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group F - Runner-up', 12, '[PHASE1_ID]', 2),
-- Group G
(gen_random_uuid(), '[EVENT_ID]', 'Group G - Winner', 13, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group G - Runner-up', 14, '[PHASE1_ID]', 2),
-- Group H
(gen_random_uuid(), '[EVENT_ID]', 'Group H - Winner', 15, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group H - Runner-up', 16, '[PHASE1_ID]', 2),
-- Group I
(gen_random_uuid(), '[EVENT_ID]', 'Group I - Winner', 17, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group I - Runner-up', 18, '[PHASE1_ID]', 2),
-- Group J
(gen_random_uuid(), '[EVENT_ID]', 'Group J - Winner', 19, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group J - Runner-up', 20, '[PHASE1_ID]', 2),
-- Group K
(gen_random_uuid(), '[EVENT_ID]', 'Group K - Winner', 21, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group K - Runner-up', 22, '[PHASE1_ID]', 2),
-- Group L
(gen_random_uuid(), '[EVENT_ID]', 'Group L - Winner', 23, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group L - Runner-up', 24, '[PHASE1_ID]', 2);

-- Verify (should be 24 categories)
SELECT name, order_index, points FROM categories WHERE event_id = '[EVENT_ID]' ORDER BY order_index;


-- ============================================
-- PART 5: LINK TEAMS TO CATEGORIES AS OPTIONS
-- ============================================

DO $$
DECLARE
  group_letter TEXT;
  cat_type TEXT;
  cat_id UUID;
  event_uuid UUID := '[EVENT_ID]'::UUID;
BEGIN
  FOREACH group_letter IN ARRAY ARRAY['A','B','C','D','E','F','G','H','I','J','K','L'] LOOP
    FOREACH cat_type IN ARRAY ARRAY['Winner', 'Runner-up'] LOOP
      SELECT id INTO cat_id 
      FROM categories 
      WHERE event_id = event_uuid 
        AND name = 'Group ' || group_letter || ' - ' || cat_type;
      
      INSERT INTO category_options (category_id, name, order_index)
      SELECT cat_id, t.name, t.seed
      FROM teams t
      WHERE t.event_id = event_uuid 
        AND t.region = 'Group ' || group_letter
      ORDER BY t.seed;
    END LOOP;
  END LOOP;
END $$;

-- Verify (should be 96 options: 48 teams × 2 categories each)
SELECT COUNT(*) as option_count FROM category_options 
WHERE category_id IN (SELECT id FROM categories WHERE event_id = '[EVENT_ID]');


-- ============================================
-- PART 6: CREATE KNOCKOUT ROUNDS
-- ============================================

INSERT INTO rounds (id, event_id, name, round_order, points) VALUES
(gen_random_uuid(), '[EVENT_ID]', 'Round of 32', 1, 3),
(gen_random_uuid(), '[EVENT_ID]', 'Round of 16', 2, 5),
(gen_random_uuid(), '[EVENT_ID]', 'Quarterfinals', 3, 8),
(gen_random_uuid(), '[EVENT_ID]', 'Semifinals', 4, 13),
(gen_random_uuid(), '[EVENT_ID]', 'Final', 5, 21);

-- Verify
SELECT name, round_order, points FROM rounds WHERE event_id = '[EVENT_ID]' ORDER BY round_order;


-- ============================================
-- PART 7: CREATE EMPTY KNOCKOUT MATCHUPS
-- ============================================

-- Round of 32 (16 matches)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id)
SELECT '[EVENT_ID]', r.id, pos, NULL, NULL
FROM rounds r, generate_series(1, 16) AS pos
WHERE r.event_id = '[EVENT_ID]' AND r.name = 'Round of 32';

-- Round of 16 (8 matches)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id)
SELECT '[EVENT_ID]', r.id, pos, NULL, NULL
FROM rounds r, generate_series(1, 8) AS pos
WHERE r.event_id = '[EVENT_ID]' AND r.name = 'Round of 16';

-- Quarterfinals (4 matches)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id)
SELECT '[EVENT_ID]', r.id, pos, NULL, NULL
FROM rounds r, generate_series(1, 4) AS pos
WHERE r.event_id = '[EVENT_ID]' AND r.name = 'Quarterfinals';

-- Semifinals (2 matches)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id)
SELECT '[EVENT_ID]', r.id, pos, NULL, NULL
FROM rounds r, generate_series(1, 2) AS pos
WHERE r.event_id = '[EVENT_ID]' AND r.name = 'Semifinals';

-- Final (1 match)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id)
SELECT '[EVENT_ID]', r.id, 1, NULL, NULL
FROM rounds r
WHERE r.event_id = '[EVENT_ID]' AND r.name = 'Final';

-- Verify (should be 31 total matchups)
SELECT r.name, COUNT(*) as matches
FROM matchups m
JOIN rounds r ON r.id = m.round_id
WHERE m.event_id = '[EVENT_ID]'
GROUP BY r.name, r.round_order
ORDER BY r.round_order;


-- ============================================
-- PART 8: CREATE POOLS
-- ============================================

-- Pool A
INSERT INTO pools (id, event_id, name, owner_email, status)
VALUES (
  gen_random_uuid(),
  '[EVENT_ID]',
  'World Cup 2026 - Pool A',
  'your@email.com',  -- CHANGE THIS
  'active'
)
RETURNING id, name;

-- Pool B
INSERT INTO pools (id, event_id, name, owner_email, status)
VALUES (
  gen_random_uuid(),
  '[EVENT_ID]',
  'World Cup 2026 - Pool B',
  'your@email.com',  -- CHANGE THIS
  'active'
)
RETURNING id, name;


-- ============================================
-- VERIFICATION SUMMARY
-- ============================================

SELECT 'Events' as item, COUNT(*) as count FROM events WHERE id = '[EVENT_ID]'
UNION ALL SELECT 'Phases', COUNT(*) FROM phases WHERE event_id = '[EVENT_ID]'
UNION ALL SELECT 'Teams', COUNT(*) FROM teams WHERE event_id = '[EVENT_ID]'
UNION ALL SELECT 'Categories', COUNT(*) FROM categories WHERE event_id = '[EVENT_ID]'
UNION ALL SELECT 'Category Options', COUNT(*) FROM category_options WHERE category_id IN (SELECT id FROM categories WHERE event_id = '[EVENT_ID]')
UNION ALL SELECT 'Rounds', COUNT(*) FROM rounds WHERE event_id = '[EVENT_ID]'
UNION ALL SELECT 'Matchups', COUNT(*) FROM matchups WHERE event_id = '[EVENT_ID]'
UNION ALL SELECT 'Pools', COUNT(*) FROM pools WHERE event_id = '[EVENT_ID]';

-- Expected:
-- Events: 1
-- Phases: 2
-- Teams: 48
-- Categories: 24
-- Category Options: 96
-- Rounds: 5
-- Matchups: 31
-- Pools: 2


-- ============================================
-- AFTER MARCH 2026 PLAYOFFS: UPDATE TEAM NAMES
-- ============================================
-- Run these after playoff results are known

/*
-- UEFA Playoff A Winner → Group B
UPDATE teams SET name = 'Italy' WHERE event_id = '[EVENT_ID]' AND name = 'UEFA Playoff A';
UPDATE category_options SET name = 'Italy' WHERE name = 'UEFA Playoff A';

-- UEFA Playoff B Winner → Group F  
UPDATE teams SET name = 'Ukraine' WHERE event_id = '[EVENT_ID]' AND name = 'UEFA Playoff B';
UPDATE category_options SET name = 'Ukraine' WHERE name = 'UEFA Playoff B';

-- UEFA Playoff C Winner → Group D
UPDATE teams SET name = 'Türkiye' WHERE event_id = '[EVENT_ID]' AND name = 'UEFA Playoff C';
UPDATE category_options SET name = 'Türkiye' WHERE name = 'UEFA Playoff C';

-- UEFA Playoff D Winner → Group A
UPDATE teams SET name = 'Denmark' WHERE event_id = '[EVENT_ID]' AND name = 'UEFA Playoff D';
UPDATE category_options SET name = 'Denmark' WHERE name = 'UEFA Playoff D';

-- Intercontinental Playoff 1 → Group K
UPDATE teams SET name = 'DR Congo' WHERE event_id = '[EVENT_ID]' AND name = 'Intercontinental 1';
UPDATE category_options SET name = 'DR Congo' WHERE name = 'Intercontinental 1';

-- Intercontinental Playoff 2 → Group I
UPDATE teams SET name = 'Iraq' WHERE event_id = '[EVENT_ID]' AND name = 'Intercontinental 2';
UPDATE category_options SET name = 'Iraq' WHERE name = 'Intercontinental 2';
*/


-- ============================================
-- OPEN FOR PICKS (when ready)
-- ============================================

/*
UPDATE phases SET status = 'open' WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage Picks';
UPDATE events SET status = 'open' WHERE id = '[EVENT_ID]';
*/
