-- Migration: Add event_type column to events table
-- This makes event type EXPLICIT rather than inferred from uses_reseeding

-- Add the column
ALTER TABLE events 
ADD COLUMN IF NOT EXISTS event_type TEXT;

-- Add comment for documentation
COMMENT ON COLUMN events.event_type IS 'Event type: bracket, advancement, pick_one, hybrid. Maps to implementation in eventTypes.js';

-- Update existing events based on current data
-- NFL Playoff (uses_reseeding = true) → 'advancement'
UPDATE events 
SET event_type = 'advancement' 
WHERE uses_reseeding = true AND event_type IS NULL;

-- Events with only categories → 'pick_one'
UPDATE events e
SET event_type = 'pick_one'
WHERE event_type IS NULL
  AND EXISTS (SELECT 1 FROM categories c WHERE c.event_id = e.id)
  AND NOT EXISTS (SELECT 1 FROM matchups m WHERE m.event_id = e.id);

-- Events with both matchups and categories → 'hybrid'  
UPDATE events e
SET event_type = 'hybrid'
WHERE event_type IS NULL
  AND EXISTS (SELECT 1 FROM matchups m WHERE m.event_id = e.id)
  AND EXISTS (SELECT 1 FROM categories c WHERE c.event_id = e.id);

-- Remaining events with matchups → 'bracket'
UPDATE events e
SET event_type = 'bracket'
WHERE event_type IS NULL
  AND EXISTS (SELECT 1 FROM matchups m WHERE m.event_id = e.id);

-- Default any remaining to 'bracket'
UPDATE events 
SET event_type = 'bracket' 
WHERE event_type IS NULL;

-- Verify the updates
SELECT id, name, event_type, uses_reseeding 
FROM events 
ORDER BY created_at DESC;
