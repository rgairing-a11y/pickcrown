// Standings Page Integration for NFL Reseeding Events
// Add this to app/pool/[poolId]/standings/page.js

// ============================================
// IMPORTS - Add at top of file
// ============================================
import NFLMyPicksButton from '../../../../components/NFLMyPicksButton'
import NFLPathToVictory from '../../../../components/NFLPathToVictory'
import NFLBracketVisualization from '../../../../components/NFLBracketVisualization'

// ============================================
// POOL QUERY - Update to include uses_reseeding
// ============================================
const { data: pool } = await supabase
  .from('pools')
  .select(`
    *, 
    event:events(
      id, name, year, start_time, season_id, event_type, uses_reseeding,
      season:seasons(id, name)
    )
  `)
  .eq('id', poolId)
  .single()

// ============================================
// STANDINGS QUERY - Use correct function
// ============================================
const usesReseeding = pool.event?.uses_reseeding === true

let standings = []
if (usesReseeding) {
  const { data } = await supabase
    .rpc('calculate_advancement_standings', { p_pool_id: poolId })
  standings = data || []
} else {
  const { data } = await supabase
    .rpc('calculate_standings', { p_pool_id: poolId })
  standings = data || []
}

// ============================================
// NFL DATA LOADING - Add for reseeding events
// ============================================
let nflData = null
if (usesReseeding) {
  // Get rounds
  const { data: rounds } = await supabase
    .from('rounds')
    .select('*')
    .eq('event_id', pool.event.id)
    .order('round_order')

  // Get teams
  const { data: teams } = await supabase
    .from('teams')
    .select('*')
    .eq('event_id', pool.event.id)
    .order('seed')

  // Get matchups (Wild Card)
  const { data: matchups } = await supabase
    .from('matchups')
    .select('*')
    .eq('event_id', pool.event.id)

  // Get eliminations
  const { data: elimData } = await supabase
    .from('team_eliminations')
    .select('*')
    .eq('event_id', pool.event.id)

  const eliminations = {}
  elimData?.forEach(e => {
    eliminations[e.team_id] = e.eliminated_in_round_id
  })

  // Get all advancement picks for path to victory
  const { data: entries } = await supabase
    .from('pool_entries')
    .select('id')
    .eq('pool_id', poolId)

  const entryIds = entries?.map(e => e.id) || []
  
  let allPicks = {}
  if (entryIds.length > 0) {
    const { data: picksData } = await supabase
      .from('advancement_picks')
      .select('*')
      .in('pool_entry_id', entryIds)

    // Group picks by entry
    picksData?.forEach(pick => {
      if (!allPicks[pick.pool_entry_id]) {
        allPicks[pick.pool_entry_id] = []
      }
      allPicks[pick.pool_entry_id].push(pick)
    })
  }

  nflData = { rounds, teams, matchups, eliminations, allPicks }
}

// ============================================
// RENDER NFL COMPONENTS
// ============================================
// Add this in the JSX where appropriate:

{usesReseeding && nflData && (
  <>
    {/* Bracket Visualization */}
    <NFLBracketVisualization
      rounds={nflData.rounds}
      teams={nflData.teams}
      eliminations={nflData.eliminations}
      matchups={nflData.matchups}
    />

    {/* Path to Victory - only if user is in pool */}
    {myEntry && (
      <NFLPathToVictory
        standings={standings}
        rounds={nflData.rounds}
        teams={nflData.teams}
        eliminations={nflData.eliminations}
        myEntryId={myEntry.id}
        allPicks={nflData.allPicks}
      />
    )}
  </>
)}

{/* My Picks Button - use NFL version for reseeding */}
{usesReseeding ? (
  <NFLMyPicksButton
    pool={pool}
    userEmail={userEmail}
  />
) : (
  <MyPicksButton /* existing props */ />
)}

// ============================================
// HIDE INCOMPATIBLE COMPONENTS FOR NFL
// ============================================
// The standard ScenarioSimulator and PathToVictory don't work with NFL reseeding.
// Only show them for non-reseeding events:

{!usesReseeding && isLocked && undecidedMatchups.length > 0 && (
  <ScenarioSimulator
    standings={standings}
    undecidedMatchups={undecidedMatchups}
    userPicks={userPicks}
    pool={pool}
  />
)}

// ============================================
// COMPLETE EXAMPLE
// ============================================
// Here's a simplified example of the full page structure:

export default async function StandingsPage({ params }) {
  const { poolId } = await params

  // ... pool query with uses_reseeding ...
  // ... standings query ...
  // ... NFL data loading if uses_reseeding ...

  const usesReseeding = pool.event?.uses_reseeding === true
  const isLocked = new Date(pool.event.start_time) < new Date()

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: 24 }}>
      <h1>{pool.name}</h1>
      
      {/* NFL Bracket Visualization */}
      {usesReseeding && nflData && (
        <NFLBracketVisualization
          rounds={nflData.rounds}
          teams={nflData.teams}
          eliminations={nflData.eliminations}
          matchups={nflData.matchups}
        />
      )}

      {/* Path to Victory */}
      {usesReseeding && myEntry && nflData && (
        <NFLPathToVictory
          standings={standings}
          rounds={nflData.rounds}
          teams={nflData.teams}
          eliminations={nflData.eliminations}
          myEntryId={myEntry.id}
          allPicks={nflData.allPicks}
        />
      )}

      {/* Standard Path to Victory for non-NFL */}
      {!usesReseeding && /* existing PathToVictory */ null}

      {/* Standings Table */}
      <StandingsTable standings={standings} />

      {/* My Picks Button */}
      <div style={{ marginTop: 24 }}>
        {usesReseeding ? (
          <NFLMyPicksButton pool={pool} userEmail={userEmail} />
        ) : (
          <MyPicksButton /* existing */ />
        )}
      </div>

      {/* Scenario Simulator - only for non-NFL */}
      {!usesReseeding && isLocked && (
        <ScenarioSimulator /* existing */ />
      )}
    </div>
  )
}
