-- ============================================
-- WORLD CUP 2026 - COMPLETE SETUP SCRIPT
-- ============================================
-- Run this in Supabase SQL Editor
-- 
-- INSTRUCTIONS:
-- 1. Run Part 1 to create event
-- 2. Copy the event_id that's returned
-- 3. Find/Replace [EVENT_ID] with your actual event ID
-- 4. Run Parts 2-7 in order
-- ============================================


-- ============================================
-- PART 1: CREATE EVENT
-- ============================================

INSERT INTO events (id, name, year, event_type, start_time, status)
VALUES (
  gen_random_uuid(),
  'FIFA World Cup',
  2026,
  'hybrid',
  '2026-06-11 11:00:00-04',
  'draft'
)
RETURNING id, name;

-- ⚠️ COPY THE ID RETURNED ABOVE
-- Then Find/Replace all [EVENT_ID] below with that ID


-- ============================================
-- PART 2: CREATE PHASES
-- ============================================

INSERT INTO phases (id, event_id, name, phase_order, lock_time, status) VALUES
(gen_random_uuid(), '[EVENT_ID]', 'Group Stage', 1, '2026-06-11 11:00:00-04', 'open'),
(gen_random_uuid(), '[EVENT_ID]', 'Knockout Round', 2, '2026-06-28 11:00:00-04', 'draft');

-- Verify and get phase IDs
SELECT id, name, status FROM phases WHERE event_id = '[EVENT_ID]' ORDER BY phase_order;


-- ============================================
-- PART 3: CREATE TEAMS (48 teams in 12 groups)
-- ============================================
-- Update team names when the draw happens!

INSERT INTO teams (event_id, name, seed, region) VALUES
-- Group A (Host: USA likely here)
('[EVENT_ID]', 'USA', 1, 'Group A'),
('[EVENT_ID]', 'Team A2', 2, 'Group A'),
('[EVENT_ID]', 'Team A3', 3, 'Group A'),
('[EVENT_ID]', 'Team A4', 4, 'Group A'),

-- Group B (Host: Mexico likely here)
('[EVENT_ID]', 'Mexico', 1, 'Group B'),
('[EVENT_ID]', 'Team B2', 2, 'Group B'),
('[EVENT_ID]', 'Team B3', 3, 'Group B'),
('[EVENT_ID]', 'Team B4', 4, 'Group B'),

-- Group C (Host: Canada likely here)
('[EVENT_ID]', 'Canada', 1, 'Group C'),
('[EVENT_ID]', 'Team C2', 2, 'Group C'),
('[EVENT_ID]', 'Team C3', 3, 'Group C'),
('[EVENT_ID]', 'Team C4', 4, 'Group C'),

-- Group D
('[EVENT_ID]', 'Team D1', 1, 'Group D'),
('[EVENT_ID]', 'Team D2', 2, 'Group D'),
('[EVENT_ID]', 'Team D3', 3, 'Group D'),
('[EVENT_ID]', 'Team D4', 4, 'Group D'),

-- Group E
('[EVENT_ID]', 'Team E1', 1, 'Group E'),
('[EVENT_ID]', 'Team E2', 2, 'Group E'),
('[EVENT_ID]', 'Team E3', 3, 'Group E'),
('[EVENT_ID]', 'Team E4', 4, 'Group E'),

-- Group F
('[EVENT_ID]', 'Team F1', 1, 'Group F'),
('[EVENT_ID]', 'Team F2', 2, 'Group F'),
('[EVENT_ID]', 'Team F3', 3, 'Group F'),
('[EVENT_ID]', 'Team F4', 4, 'Group F'),

-- Group G
('[EVENT_ID]', 'Team G1', 1, 'Group G'),
('[EVENT_ID]', 'Team G2', 2, 'Group G'),
('[EVENT_ID]', 'Team G3', 3, 'Group G'),
('[EVENT_ID]', 'Team G4', 4, 'Group G'),

-- Group H
('[EVENT_ID]', 'Team H1', 1, 'Group H'),
('[EVENT_ID]', 'Team H2', 2, 'Group H'),
('[EVENT_ID]', 'Team H3', 3, 'Group H'),
('[EVENT_ID]', 'Team H4', 4, 'Group H'),

-- Group I
('[EVENT_ID]', 'Team I1', 1, 'Group I'),
('[EVENT_ID]', 'Team I2', 2, 'Group I'),
('[EVENT_ID]', 'Team I3', 3, 'Group I'),
('[EVENT_ID]', 'Team I4', 4, 'Group I'),

-- Group J
('[EVENT_ID]', 'Team J1', 1, 'Group J'),
('[EVENT_ID]', 'Team J2', 2, 'Group J'),
('[EVENT_ID]', 'Team J3', 3, 'Group J'),
('[EVENT_ID]', 'Team J4', 4, 'Group J'),

-- Group K
('[EVENT_ID]', 'Team K1', 1, 'Group K'),
('[EVENT_ID]', 'Team K2', 2, 'Group K'),
('[EVENT_ID]', 'Team K3', 3, 'Group K'),
('[EVENT_ID]', 'Team K4', 4, 'Group K'),

-- Group L
('[EVENT_ID]', 'Team L1', 1, 'Group L'),
('[EVENT_ID]', 'Team L2', 2, 'Group L'),
('[EVENT_ID]', 'Team L3', 3, 'Group L'),
('[EVENT_ID]', 'Team L4', 4, 'Group L');

-- Verify
SELECT region, name, seed FROM teams WHERE event_id = '[EVENT_ID]' ORDER BY region, seed;


-- ============================================
-- PART 4: CREATE GROUP STAGE CATEGORIES
-- ============================================

-- First get the Phase 1 ID
-- SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage';
-- Replace [PHASE1_ID] below

INSERT INTO categories (id, event_id, name, order_index, phase_id, points) VALUES
-- Group A
(gen_random_uuid(), '[EVENT_ID]', 'Group A - Winner', 1, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group A - Runner-up', 2, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
-- Group B
(gen_random_uuid(), '[EVENT_ID]', 'Group B - Winner', 3, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group B - Runner-up', 4, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
-- Group C
(gen_random_uuid(), '[EVENT_ID]', 'Group C - Winner', 5, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group C - Runner-up', 6, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
-- Group D
(gen_random_uuid(), '[EVENT_ID]', 'Group D - Winner', 7, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group D - Runner-up', 8, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
-- Group E
(gen_random_uuid(), '[EVENT_ID]', 'Group E - Winner', 9, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group E - Runner-up', 10, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
-- Group F
(gen_random_uuid(), '[EVENT_ID]', 'Group F - Winner', 11, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group F - Runner-up', 12, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
-- Group G
(gen_random_uuid(), '[EVENT_ID]', 'Group G - Winner', 13, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group G - Runner-up', 14, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
-- Group H
(gen_random_uuid(), '[EVENT_ID]', 'Group H - Winner', 15, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group H - Runner-up', 16, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
-- Group I
(gen_random_uuid(), '[EVENT_ID]', 'Group I - Winner', 17, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group I - Runner-up', 18, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
-- Group J
(gen_random_uuid(), '[EVENT_ID]', 'Group J - Winner', 19, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group J - Runner-up', 20, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
-- Group K
(gen_random_uuid(), '[EVENT_ID]', 'Group K - Winner', 21, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group K - Runner-up', 22, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
-- Group L
(gen_random_uuid(), '[EVENT_ID]', 'Group L - Winner', 23, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group L - Runner-up', 24, (SELECT id FROM phases WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage'), 2);

-- Verify
SELECT name, order_index, points FROM categories WHERE event_id = '[EVENT_ID]' ORDER BY order_index;


-- ============================================
-- PART 5: LINK TEAMS TO CATEGORIES AS OPTIONS
-- ============================================

-- This creates the dropdown options for each group pick
-- Using a loop to create all at once

DO $$
DECLARE
  group_letter TEXT;
  cat_type TEXT;
  cat_id UUID;
  event_uuid UUID := '[EVENT_ID]'::UUID;
BEGIN
  FOREACH group_letter IN ARRAY ARRAY['A','B','C','D','E','F','G','H','I','J','K','L'] LOOP
    FOREACH cat_type IN ARRAY ARRAY['Winner', 'Runner-up'] LOOP
      -- Get category ID
      SELECT id INTO cat_id 
      FROM categories 
      WHERE event_id = event_uuid 
        AND name = 'Group ' || group_letter || ' - ' || cat_type;
      
      -- Insert team options
      INSERT INTO category_options (category_id, name, order_index)
      SELECT cat_id, t.name, t.seed
      FROM teams t
      WHERE t.event_id = event_uuid 
        AND t.region = 'Group ' || group_letter
      ORDER BY t.seed;
    END LOOP;
  END LOOP;
END $$;

-- Verify (should show 48 teams × 2 categories each = 96 options)
SELECT c.name as category, co.name as team_option, co.order_index
FROM categories c
JOIN category_options co ON co.category_id = c.id
WHERE c.event_id = '[EVENT_ID]'
ORDER BY c.order_index, co.order_index;


-- ============================================
-- PART 6: CREATE KNOCKOUT ROUNDS
-- ============================================

INSERT INTO rounds (id, event_id, name, round_order, points) VALUES
(gen_random_uuid(), '[EVENT_ID]', 'Round of 32', 1, 3),
(gen_random_uuid(), '[EVENT_ID]', 'Round of 16', 2, 5),
(gen_random_uuid(), '[EVENT_ID]', 'Quarterfinals', 3, 8),
(gen_random_uuid(), '[EVENT_ID]', 'Semifinals', 4, 13),
(gen_random_uuid(), '[EVENT_ID]', 'Final', 5, 21);

-- Verify
SELECT id, name, round_order, points FROM rounds WHERE event_id = '[EVENT_ID]' ORDER BY round_order;


-- ============================================
-- PART 7: CREATE EMPTY KNOCKOUT MATCHUPS
-- ============================================

-- Round of 32 (16 matches) - Teams filled in after group stage
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id)
SELECT '[EVENT_ID]', r.id, pos, NULL, NULL
FROM rounds r, generate_series(1, 16) AS pos
WHERE r.event_id = '[EVENT_ID]' AND r.name = 'Round of 32';

-- Round of 16 (8 matches)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id)
SELECT '[EVENT_ID]', r.id, pos, NULL, NULL
FROM rounds r, generate_series(1, 8) AS pos
WHERE r.event_id = '[EVENT_ID]' AND r.name = 'Round of 16';

-- Quarterfinals (4 matches)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id)
SELECT '[EVENT_ID]', r.id, pos, NULL, NULL
FROM rounds r, generate_series(1, 4) AS pos
WHERE r.event_id = '[EVENT_ID]' AND r.name = 'Quarterfinals';

-- Semifinals (2 matches)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id)
SELECT '[EVENT_ID]', r.id, pos, NULL, NULL
FROM rounds r, generate_series(1, 2) AS pos
WHERE r.event_id = '[EVENT_ID]' AND r.name = 'Semifinals';

-- Final (1 match)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id)
SELECT '[EVENT_ID]', r.id, 1, NULL, NULL
FROM rounds r
WHERE r.event_id = '[EVENT_ID]' AND r.name = 'Final';

-- Verify (should have 31 total matchups)
SELECT r.name as round, COUNT(*) as matchups
FROM matchups m
JOIN rounds r ON r.id = m.round_id
WHERE m.event_id = '[EVENT_ID]'
GROUP BY r.name, r.round_order
ORDER BY r.round_order;


-- ============================================
-- PART 8: CREATE POOLS
-- ============================================

-- Pool A
INSERT INTO pools (id, event_id, name, owner_email, status)
VALUES (
  gen_random_uuid(),
  '[EVENT_ID]',
  'World Cup 2026 - Pool A',
  'your@email.com',  -- Change this!
  'active'
)
RETURNING id, name;

-- Pool B  
INSERT INTO pools (id, event_id, name, owner_email, status)
VALUES (
  gen_random_uuid(),
  '[EVENT_ID]',
  'World Cup 2026 - Pool B',
  'your@email.com',  -- Change this!
  'active'
)
RETURNING id, name;


-- ============================================
-- FINAL VERIFICATION
-- ============================================

SELECT 'Event' as type, COUNT(*) as count FROM events WHERE id = '[EVENT_ID]'
UNION ALL
SELECT 'Phases', COUNT(*) FROM phases WHERE event_id = '[EVENT_ID]'
UNION ALL
SELECT 'Teams', COUNT(*) FROM teams WHERE event_id = '[EVENT_ID]'
UNION ALL
SELECT 'Categories', COUNT(*) FROM categories WHERE event_id = '[EVENT_ID]'
UNION ALL
SELECT 'Category Options', COUNT(*) FROM category_options WHERE category_id IN (SELECT id FROM categories WHERE event_id = '[EVENT_ID]')
UNION ALL
SELECT 'Rounds', COUNT(*) FROM rounds WHERE event_id = '[EVENT_ID]'
UNION ALL
SELECT 'Matchups', COUNT(*) FROM matchups WHERE event_id = '[EVENT_ID]'
UNION ALL
SELECT 'Pools', COUNT(*) FROM pools WHERE event_id = '[EVENT_ID]';

-- Expected:
-- Event: 1
-- Phases: 2
-- Teams: 48
-- Categories: 24
-- Category Options: 96
-- Rounds: 5
-- Matchups: 31
-- Pools: 2


-- ============================================
-- WHEN READY: OPEN THE EVENT
-- ============================================
-- UPDATE events SET status = 'open' WHERE id = '[EVENT_ID]';
