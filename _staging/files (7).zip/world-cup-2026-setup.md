# World Cup Pool Setup Guide

## 2026 Format Overview

FIFA World Cup 2026 (USA/Mexico/Canada) uses an **expanded 48-team format**:
- **12 groups** of 4 teams each
- **Top 2** from each group advance (24 teams)
- **8 best 3rd-place** teams advance (32 total)
- **Knockout round**: Round of 32 → R16 → QF → SF → Final

---

## Two-Phase Pool Structure

### Phase 1: Group Stage Picks
- Pick 1st and 2nd place for each group
- 12 groups × 2 picks = **24 picks**
- Points: 2 per correct pick
- **Max: 48 points**

### Phase 2: Knockout Bracket
- Opens after group stage completes
- Actual qualified teams populated
- Round of 32 through Final = **31 picks**
- Points: 3/5/8/13/21
- **Max: 16×3 + 8×5 + 4×8 + 2×13 + 1×21 = 48 + 40 + 32 + 26 + 21 = 167 points**

**Total Max: 215 points**

---

## Setup SQL

### Part 1: Create Event and Phases

```sql
-- ============================================
-- WORLD CUP 2026 - EVENT SETUP
-- ============================================

-- Step 1: Create the event
INSERT INTO events (id, name, year, event_type, start_time, status)
VALUES (
  gen_random_uuid(),
  'FIFA World Cup',
  2026,
  'hybrid',
  '2026-06-11 11:00:00-04',  -- First match (adjust as needed)
  'draft'
)
RETURNING id;

-- ⚠️ SAVE THIS EVENT ID - you'll need it for all subsequent queries
-- Example: 'abc123-event-uuid'
```

```sql
-- Step 2: Create phases (replace [EVENT_ID] with actual ID)
INSERT INTO phases (id, event_id, name, phase_order, lock_time, status) VALUES
(gen_random_uuid(), '[EVENT_ID]', 'Group Stage', 1, '2026-06-11 11:00:00-04', 'open'),
(gen_random_uuid(), '[EVENT_ID]', 'Knockout Round', 2, '2026-06-28 11:00:00-04', 'draft');

-- Get phase IDs
SELECT id, name FROM phases WHERE event_id = '[EVENT_ID]';
-- Save PHASE1_ID (Group Stage) and PHASE2_ID (Knockout Round)
```

---

### Part 2: Create All Teams

```sql
-- ============================================
-- TEAMS - All 48 World Cup Teams
-- ============================================
-- Replace [EVENT_ID] with your event ID
-- Update team names when draw is finalized

INSERT INTO teams (event_id, name, seed, region) VALUES
-- Group A
('[EVENT_ID]', 'USA', 1, 'Group A'),
('[EVENT_ID]', 'Team A2', 2, 'Group A'),
('[EVENT_ID]', 'Team A3', 3, 'Group A'),
('[EVENT_ID]', 'Team A4', 4, 'Group A'),

-- Group B
('[EVENT_ID]', 'Mexico', 1, 'Group B'),
('[EVENT_ID]', 'Team B2', 2, 'Group B'),
('[EVENT_ID]', 'Team B3', 3, 'Group B'),
('[EVENT_ID]', 'Team B4', 4, 'Group B'),

-- Group C
('[EVENT_ID]', 'Canada', 1, 'Group C'),
('[EVENT_ID]', 'Team C2', 2, 'Group C'),
('[EVENT_ID]', 'Team C3', 3, 'Group C'),
('[EVENT_ID]', 'Team C4', 4, 'Group C'),

-- Group D
('[EVENT_ID]', 'Team D1', 1, 'Group D'),
('[EVENT_ID]', 'Team D2', 2, 'Group D'),
('[EVENT_ID]', 'Team D3', 3, 'Group D'),
('[EVENT_ID]', 'Team D4', 4, 'Group D'),

-- Group E
('[EVENT_ID]', 'Team E1', 1, 'Group E'),
('[EVENT_ID]', 'Team E2', 2, 'Group E'),
('[EVENT_ID]', 'Team E3', 3, 'Group E'),
('[EVENT_ID]', 'Team E4', 4, 'Group E'),

-- Group F
('[EVENT_ID]', 'Team F1', 1, 'Group F'),
('[EVENT_ID]', 'Team F2', 2, 'Group F'),
('[EVENT_ID]', 'Team F3', 3, 'Group F'),
('[EVENT_ID]', 'Team F4', 4, 'Group F'),

-- Group G
('[EVENT_ID]', 'Team G1', 1, 'Group G'),
('[EVENT_ID]', 'Team G2', 2, 'Group G'),
('[EVENT_ID]', 'Team G3', 3, 'Group G'),
('[EVENT_ID]', 'Team G4', 4, 'Group G'),

-- Group H
('[EVENT_ID]', 'Team H1', 1, 'Group H'),
('[EVENT_ID]', 'Team H2', 2, 'Group H'),
('[EVENT_ID]', 'Team H3', 3, 'Group H'),
('[EVENT_ID]', 'Team H4', 4, 'Group H'),

-- Group I
('[EVENT_ID]', 'Team I1', 1, 'Group I'),
('[EVENT_ID]', 'Team I2', 2, 'Group I'),
('[EVENT_ID]', 'Team I3', 3, 'Group I'),
('[EVENT_ID]', 'Team I4', 4, 'Group I'),

-- Group J
('[EVENT_ID]', 'Team J1', 1, 'Group J'),
('[EVENT_ID]', 'Team J2', 2, 'Group J'),
('[EVENT_ID]', 'Team J3', 3, 'Group J'),
('[EVENT_ID]', 'Team J4', 4, 'Group J'),

-- Group K
('[EVENT_ID]', 'Team K1', 1, 'Group K'),
('[EVENT_ID]', 'Team K2', 2, 'Group K'),
('[EVENT_ID]', 'Team K3', 3, 'Group K'),
('[EVENT_ID]', 'Team K4', 4, 'Group K'),

-- Group L
('[EVENT_ID]', 'Team L1', 1, 'Group L'),
('[EVENT_ID]', 'Team L2', 2, 'Group L'),
('[EVENT_ID]', 'Team L3', 3, 'Group L'),
('[EVENT_ID]', 'Team L4', 4, 'Group L');
```

---

### Part 3: Create Group Stage Categories

```sql
-- ============================================
-- PHASE 1: GROUP STAGE CATEGORIES
-- ============================================
-- Replace [EVENT_ID] and [PHASE1_ID]

-- Create all 24 categories (1st and 2nd place for each group)
INSERT INTO categories (id, event_id, name, order_index, phase_id, points) VALUES
-- Group A
(gen_random_uuid(), '[EVENT_ID]', 'Group A - Winner', 1, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group A - Runner-up', 2, '[PHASE1_ID]', 2),
-- Group B
(gen_random_uuid(), '[EVENT_ID]', 'Group B - Winner', 3, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group B - Runner-up', 4, '[PHASE1_ID]', 2),
-- Group C
(gen_random_uuid(), '[EVENT_ID]', 'Group C - Winner', 5, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group C - Runner-up', 6, '[PHASE1_ID]', 2),
-- Group D
(gen_random_uuid(), '[EVENT_ID]', 'Group D - Winner', 7, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group D - Runner-up', 8, '[PHASE1_ID]', 2),
-- Group E
(gen_random_uuid(), '[EVENT_ID]', 'Group E - Winner', 9, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group E - Runner-up', 10, '[PHASE1_ID]', 2),
-- Group F
(gen_random_uuid(), '[EVENT_ID]', 'Group F - Winner', 11, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group F - Runner-up', 12, '[PHASE1_ID]', 2),
-- Group G
(gen_random_uuid(), '[EVENT_ID]', 'Group G - Winner', 13, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group G - Runner-up', 14, '[PHASE1_ID]', 2),
-- Group H
(gen_random_uuid(), '[EVENT_ID]', 'Group H - Winner', 15, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group H - Runner-up', 16, '[PHASE1_ID]', 2),
-- Group I
(gen_random_uuid(), '[EVENT_ID]', 'Group I - Winner', 17, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group I - Runner-up', 18, '[PHASE1_ID]', 2),
-- Group J
(gen_random_uuid(), '[EVENT_ID]', 'Group J - Winner', 19, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group J - Runner-up', 20, '[PHASE1_ID]', 2),
-- Group K
(gen_random_uuid(), '[EVENT_ID]', 'Group K - Winner', 21, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group K - Runner-up', 22, '[PHASE1_ID]', 2),
-- Group L
(gen_random_uuid(), '[EVENT_ID]', 'Group L - Winner', 23, '[PHASE1_ID]', 2),
(gen_random_uuid(), '[EVENT_ID]', 'Group L - Runner-up', 24, '[PHASE1_ID]', 2);
```

---

### Part 4: Create Category Options (Team Choices)

```sql
-- ============================================
-- CATEGORY OPTIONS - Link teams to categories
-- ============================================
-- This creates the dropdown options for each group pick

-- Get category and team IDs
SELECT c.id, c.name FROM categories c WHERE c.event_id = '[EVENT_ID]' ORDER BY c.order_index;
SELECT t.id, t.name, t.region FROM teams t WHERE t.event_id = '[EVENT_ID]' ORDER BY t.region, t.seed;

-- For each group, insert the 4 teams as options for both Winner and Runner-up categories
-- Example for Group A (repeat pattern for all groups):

-- Group A Winner options
INSERT INTO category_options (category_id, name, order_index) 
SELECT 
  (SELECT id FROM categories WHERE event_id = '[EVENT_ID]' AND name = 'Group A - Winner'),
  t.name,
  t.seed
FROM teams t 
WHERE t.event_id = '[EVENT_ID]' AND t.region = 'Group A'
ORDER BY t.seed;

-- Group A Runner-up options
INSERT INTO category_options (category_id, name, order_index) 
SELECT 
  (SELECT id FROM categories WHERE event_id = '[EVENT_ID]' AND name = 'Group A - Runner-up'),
  t.name,
  t.seed
FROM teams t 
WHERE t.event_id = '[EVENT_ID]' AND t.region = 'Group A'
ORDER BY t.seed;

-- Repeat for Groups B through L...
```

**Shortcut - Generate all at once:**

```sql
-- Insert options for ALL groups at once
DO $$
DECLARE
  group_letter TEXT;
  cat_type TEXT;
  cat_id UUID;
BEGIN
  FOREACH group_letter IN ARRAY ARRAY['A','B','C','D','E','F','G','H','I','J','K','L'] LOOP
    FOREACH cat_type IN ARRAY ARRAY['Winner', 'Runner-up'] LOOP
      -- Get category ID
      SELECT id INTO cat_id 
      FROM categories 
      WHERE event_id = '[EVENT_ID]' 
        AND name = 'Group ' || group_letter || ' - ' || cat_type;
      
      -- Insert team options
      INSERT INTO category_options (category_id, name, order_index)
      SELECT cat_id, t.name, t.seed
      FROM teams t
      WHERE t.event_id = '[EVENT_ID]' 
        AND t.region = 'Group ' || group_letter
      ORDER BY t.seed;
    END LOOP;
  END LOOP;
END $$;
```

---

### Part 5: Create Knockout Rounds

```sql
-- ============================================
-- KNOCKOUT ROUNDS
-- ============================================
-- Replace [EVENT_ID]

INSERT INTO rounds (id, event_id, name, round_order, points) VALUES
(gen_random_uuid(), '[EVENT_ID]', 'Round of 32', 1, 3),
(gen_random_uuid(), '[EVENT_ID]', 'Round of 16', 2, 5),
(gen_random_uuid(), '[EVENT_ID]', 'Quarterfinals', 3, 8),
(gen_random_uuid(), '[EVENT_ID]', 'Semifinals', 4, 13),
(gen_random_uuid(), '[EVENT_ID]', 'Final', 5, 21);

-- Get round IDs
SELECT id, name, round_order FROM rounds WHERE event_id = '[EVENT_ID]' ORDER BY round_order;
```

---

### Part 6: Create Empty Knockout Matchups

```sql
-- ============================================
-- KNOCKOUT MATCHUPS (Teams TBD until groups finish)
-- ============================================
-- Replace [EVENT_ID] and round IDs

-- Round of 32 (16 matches)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id) VALUES
('[EVENT_ID]', '[R32_ID]', 1, NULL, NULL),   -- 1A vs 3C/D/E
('[EVENT_ID]', '[R32_ID]', 2, NULL, NULL),   -- 2A vs 2B
('[EVENT_ID]', '[R32_ID]', 3, NULL, NULL),   -- 1B vs 3A/D/E/F
('[EVENT_ID]', '[R32_ID]', 4, NULL, NULL),   -- 1C vs 3D/E/F
('[EVENT_ID]', '[R32_ID]', 5, NULL, NULL),   -- 2C vs 1D
('[EVENT_ID]', '[R32_ID]', 6, NULL, NULL),   -- 2D vs 2E
('[EVENT_ID]', '[R32_ID]', 7, NULL, NULL),   -- 1E vs 3A/B/C
('[EVENT_ID]', '[R32_ID]', 8, NULL, NULL),   -- 1F vs 3A/B/C/D
('[EVENT_ID]', '[R32_ID]', 9, NULL, NULL),   -- 2F vs 1G
('[EVENT_ID]', '[R32_ID]', 10, NULL, NULL),  -- 2G vs 2H
('[EVENT_ID]', '[R32_ID]', 11, NULL, NULL),  -- 1H vs 3G/H/I/J
('[EVENT_ID]', '[R32_ID]', 12, NULL, NULL),  -- 1I vs 3F/G/H/I
('[EVENT_ID]', '[R32_ID]', 13, NULL, NULL),  -- 2I vs 1J
('[EVENT_ID]', '[R32_ID]', 14, NULL, NULL),  -- 2J vs 2K
('[EVENT_ID]', '[R32_ID]', 15, NULL, NULL),  -- 1K vs 3I/J/K/L
('[EVENT_ID]', '[R32_ID]', 16, NULL, NULL);  -- 1L vs 2L

-- Round of 16 (8 matches)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id) VALUES
('[EVENT_ID]', '[R16_ID]', 1, NULL, NULL),   -- Winner R32-1 vs Winner R32-2
('[EVENT_ID]', '[R16_ID]', 2, NULL, NULL),
('[EVENT_ID]', '[R16_ID]', 3, NULL, NULL),
('[EVENT_ID]', '[R16_ID]', 4, NULL, NULL),
('[EVENT_ID]', '[R16_ID]', 5, NULL, NULL),
('[EVENT_ID]', '[R16_ID]', 6, NULL, NULL),
('[EVENT_ID]', '[R16_ID]', 7, NULL, NULL),
('[EVENT_ID]', '[R16_ID]', 8, NULL, NULL);

-- Quarterfinals (4 matches)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id) VALUES
('[EVENT_ID]', '[QF_ID]', 1, NULL, NULL),
('[EVENT_ID]', '[QF_ID]', 2, NULL, NULL),
('[EVENT_ID]', '[QF_ID]', 3, NULL, NULL),
('[EVENT_ID]', '[QF_ID]', 4, NULL, NULL);

-- Semifinals (2 matches)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id) VALUES
('[EVENT_ID]', '[SF_ID]', 1, NULL, NULL),
('[EVENT_ID]', '[SF_ID]', 2, NULL, NULL);

-- Final (1 match)
INSERT INTO matchups (event_id, round_id, bracket_position, team_a_id, team_b_id) VALUES
('[EVENT_ID]', '[FINAL_ID]', 1, NULL, NULL);
```

---

### Part 7: Create Pools

```sql
-- ============================================
-- CREATE POOLS
-- ============================================

-- Pool A (already exists?)
INSERT INTO pools (id, event_id, name, owner_email, status)
VALUES (
  gen_random_uuid(),
  '[EVENT_ID]',
  'World Cup 2026 - Pool A',
  'your@email.com',
  'active'
);

-- Pool B
INSERT INTO pools (id, event_id, name, owner_email, status)
VALUES (
  gen_random_uuid(),
  '[EVENT_ID]',
  'World Cup 2026 - Pool B',
  'your@email.com',
  'active'
);
```

---

## Phase Transitions

### After Group Stage Ends

1. **Mark group results correct:**
```sql
-- Example: Germany won Group A
UPDATE category_options 
SET is_correct = TRUE 
WHERE category_id = (SELECT id FROM categories WHERE name = 'Group A - Winner' AND event_id = '[EVENT_ID]')
  AND name = 'Germany';
```

2. **Complete Phase 1:**
```sql
UPDATE phases SET status = 'completed' WHERE name = 'Group Stage' AND event_id = '[EVENT_ID]';
```

3. **Populate Round of 32 matchups with actual teams:**
```sql
-- Example: Match 1 is 1A vs 3rd place team
UPDATE matchups 
SET team_a_id = (SELECT id FROM teams WHERE name = 'Germany' AND event_id = '[EVENT_ID]'),
    team_b_id = (SELECT id FROM teams WHERE name = 'Ecuador' AND event_id = '[EVENT_ID]')
WHERE event_id = '[EVENT_ID]' 
  AND round_id = '[R32_ID]' 
  AND bracket_position = 1;
```

4. **Open Phase 2:**
```sql
UPDATE phases SET status = 'open' WHERE name = 'Knockout Round' AND event_id = '[EVENT_ID]';
```

---

## Verification Queries

```sql
-- Check event setup
SELECT * FROM events WHERE name LIKE '%World Cup%';

-- Check phases
SELECT * FROM phases WHERE event_id = '[EVENT_ID]' ORDER BY phase_order;

-- Check categories per group
SELECT name, order_index, points FROM categories WHERE event_id = '[EVENT_ID]' ORDER BY order_index;

-- Check teams per group
SELECT region, name, seed FROM teams WHERE event_id = '[EVENT_ID]' ORDER BY region, seed;

-- Check options are linked
SELECT c.name as category, co.name as option 
FROM categories c
JOIN category_options co ON co.category_id = c.id
WHERE c.event_id = '[EVENT_ID]'
ORDER BY c.order_index, co.order_index;

-- Check rounds
SELECT name, round_order, points FROM rounds WHERE event_id = '[EVENT_ID]' ORDER BY round_order;

-- Check matchups
SELECT r.name as round, m.bracket_position, ta.name as team_a, tb.name as team_b
FROM matchups m
JOIN rounds r ON r.id = m.round_id
LEFT JOIN teams ta ON ta.id = m.team_a_id
LEFT JOIN teams tb ON tb.id = m.team_b_id
WHERE m.event_id = '[EVENT_ID]'
ORDER BY r.round_order, m.bracket_position;

-- Check pools
SELECT * FROM pools WHERE event_id = '[EVENT_ID]';
```

---

## Quick Reference

| Item | Count |
|------|-------|
| Teams | 48 |
| Groups | 12 |
| Phase 1 Categories | 24 |
| Phase 1 Max Points | 48 |
| Knockout Rounds | 5 |
| Knockout Matchups | 31 |
| Phase 2 Max Points | 167 |
| **Total Max Points** | **215** |

---

## Timeline

| Date | Action |
|------|--------|
| Before draw | Create event, phases, rounds, matchups |
| After draw | Add team names |
| Before tournament | Open Phase 1, create pools |
| Group stage ends | Enter results, complete Phase 1 |
| Before R32 | Populate matchups, open Phase 2 |
| After final | Enter results, send results emails |

---

## Alternative: Simpler 32-Team Format

If you want the traditional 32-team format (8 groups), use this instead:

- 8 groups × 4 teams = 32 teams
- 8 groups × 2 picks = 16 group picks
- Round of 16 → QF → SF → Final = 15 knockout picks
- Total: 31 picks

Just modify the SQL to use Groups A-H instead of A-L.
