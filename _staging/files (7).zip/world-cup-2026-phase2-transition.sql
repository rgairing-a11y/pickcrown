-- ============================================
-- WORLD CUP 2026 - PHASE 2 TRANSITION
-- ============================================
-- Run this AFTER group stage is complete
-- 
-- Replace [EVENT_ID] with your event ID
-- ============================================


-- ============================================
-- STEP 1: MARK GROUP RESULTS AS CORRECT
-- ============================================

-- Example: If USA won Group A and Team A2 was runner-up
UPDATE category_options 
SET is_correct = TRUE 
WHERE category_id = (SELECT id FROM categories WHERE name = 'Group A - Winner' AND event_id = '[EVENT_ID]')
  AND name = 'USA';

UPDATE category_options 
SET is_correct = TRUE 
WHERE category_id = (SELECT id FROM categories WHERE name = 'Group A - Runner-up' AND event_id = '[EVENT_ID]')
  AND name = 'Team A2';

-- Repeat for all 12 groups...
-- Group B
UPDATE category_options SET is_correct = TRUE 
WHERE category_id = (SELECT id FROM categories WHERE name = 'Group B - Winner' AND event_id = '[EVENT_ID]')
  AND name = 'WINNER_NAME_HERE';

UPDATE category_options SET is_correct = TRUE 
WHERE category_id = (SELECT id FROM categories WHERE name = 'Group B - Runner-up' AND event_id = '[EVENT_ID]')
  AND name = 'RUNNER_UP_NAME_HERE';

-- ... continue for Groups C through L


-- ============================================
-- STEP 2: COMPLETE PHASE 1
-- ============================================

UPDATE phases 
SET status = 'completed' 
WHERE event_id = '[EVENT_ID]' AND name = 'Group Stage';


-- ============================================
-- STEP 3: POPULATE ROUND OF 32 MATCHUPS
-- ============================================

-- Get the Round of 32 round_id
-- SELECT id FROM rounds WHERE event_id = '[EVENT_ID]' AND name = 'Round of 32';

-- Example: Match 1 is 1A vs best 3rd place team
-- Replace team names with actual qualifiers

UPDATE matchups SET 
  team_a_id = (SELECT id FROM teams WHERE event_id = '[EVENT_ID]' AND name = 'USA'),
  team_b_id = (SELECT id FROM teams WHERE event_id = '[EVENT_ID]' AND name = 'THIRD_PLACE_TEAM')
WHERE event_id = '[EVENT_ID]' 
  AND round_id = (SELECT id FROM rounds WHERE event_id = '[EVENT_ID]' AND name = 'Round of 32')
  AND bracket_position = 1;

-- Match 2
UPDATE matchups SET 
  team_a_id = (SELECT id FROM teams WHERE event_id = '[EVENT_ID]' AND name = 'TEAM_X'),
  team_b_id = (SELECT id FROM teams WHERE event_id = '[EVENT_ID]' AND name = 'TEAM_Y')
WHERE event_id = '[EVENT_ID]' 
  AND round_id = (SELECT id FROM rounds WHERE event_id = '[EVENT_ID]' AND name = 'Round of 32')
  AND bracket_position = 2;

-- ... continue for all 16 Round of 32 matches


-- ============================================
-- STEP 4: OPEN PHASE 2
-- ============================================

UPDATE phases 
SET status = 'open' 
WHERE event_id = '[EVENT_ID]' AND name = 'Knockout Round';


-- ============================================
-- VERIFY PHASE TRANSITION
-- ============================================

-- Check phases
SELECT name, status, lock_time FROM phases WHERE event_id = '[EVENT_ID]' ORDER BY phase_order;

-- Check that matchups are populated
SELECT 
  m.bracket_position,
  ta.name as team_a,
  tb.name as team_b
FROM matchups m
JOIN rounds r ON r.id = m.round_id
LEFT JOIN teams ta ON ta.id = m.team_a_id
LEFT JOIN teams tb ON tb.id = m.team_b_id
WHERE m.event_id = '[EVENT_ID]' AND r.name = 'Round of 32'
ORDER BY m.bracket_position;


-- ============================================
-- LATER: ENTER KNOCKOUT RESULTS
-- ============================================

-- After each Round of 32 match, set winner
UPDATE matchups 
SET winner_team_id = (SELECT id FROM teams WHERE event_id = '[EVENT_ID]' AND name = 'WINNING_TEAM')
WHERE event_id = '[EVENT_ID]' 
  AND round_id = (SELECT id FROM rounds WHERE event_id = '[EVENT_ID]' AND name = 'Round of 32')
  AND bracket_position = 1;

-- Then populate Round of 16 matchups with winners...
-- And so on through the Final
